import { ProfileProvider } from "../../../contexts/useProfile";
import LoginPage from "./registerPage";

export default function Login(){
    return (
        <LoginPage />
    )
}